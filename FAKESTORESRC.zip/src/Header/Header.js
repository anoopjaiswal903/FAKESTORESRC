import React from "react";
import {
  Header,
  HeaderContainer,
  HeaderName,
  HeaderNavigation,
  HeaderMenuButton,
  HeaderMenuItem,
  HeaderGlobalBar,
  HeaderGlobalAction,
  SkipToContent,
  HeaderSideNavItems,
} from "@carbon/react";

const TutorialHeader = () => (
  <HeaderContainer
    render={({ isSideNavExpanded, onClickSideNavExpand }) => (
      <Header aria-label="Carbon Tutorial">
        <SkipToContent />
        <HeaderMenuButton
          aria-label="Open menu"
          onClick={onClickSideNavExpand}
          isActive={isSideNavExpanded}
        />
        {/* <HeaderName href="/" prefix="IBM">
          FAKE STORE
        </HeaderName> */}
        <HeaderNavigation aria-label="Carbon Tutorial">
          <HeaderMenuItem href="/">FAKE STORE</HeaderMenuItem>
          <HeaderMenuItem href="/repos">Repositories</HeaderMenuItem>
        </HeaderNavigation>
        <HeaderGlobalBar />
      </Header>
    )}
  />
);

export default TutorialHeader;
