import { React, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchProduct } from "./ProductSlice";
import { ClickableTile, Loading } from "@carbon/react";
import "./product.scss";

function ProductView() {
  const product = useSelector((state) => state.product);
  console.log(product);

  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchProduct());
  }, []);
  return (
    <div>
      {product.loading && (
        <div>
          <Loading>Loading........</Loading>
        </div>
      )}

      {!product.loading && product.error ? (
        <div>ERROR : {product.error}</div>
      ) : null}

      {!product.loading && product.products.length ? (
        <div class="cds--grid">
          <div class="cds--row">
            {product.products.map((item) => (
              <div class="cds--col-lg-4 cds--col-md-4 cds--col-sm-4 items">
                <ClickableTile id="tile-1" href="">
                  <div>
                    <img class="img1" src={item.image}></img>
                    <div> {`TITLE : ${item.title.substring(0, 14)}`}</div>
                    <div>
                      {`DESCRIPTION : ${item.description.substring(0, 14)}`}
                    </div>
                    <div> {`PRICE $ ${item.price}`}</div>
                  </div>
                </ClickableTile>
              </div>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}

export default ProductView;
