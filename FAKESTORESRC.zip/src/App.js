import "./App.scss";

import { Button, Content } from "@carbon/react";

import ProductView from "./Fakestore/Products/ProductView";

import Header from "./Header";

function App() {
  return (
    <div className="App">
      <Header />
      <Content>
        <ProductView />
      </Content>
    </div>
  );
}

export default App;
